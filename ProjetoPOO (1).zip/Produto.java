public class Produto{
  private String nome_produto;
  private String descricao;
  private double preco;
  private double quant;

  public Produto(String nomeProduto, String descricao, double preco){
    this.nome_produto = nomeProduto;
    this.descricao = descricao;
    this.preco = preco;
    this.quant = 0;
  }

  public void setQuant(double quant){
      this.quant = quant;
  }
  public String get_nome_produto(){
    return this.nome_produto;
  }
  public String get_descricao(){
    return this.descricao;
  } 
  public double get_preco(){
    return this.preco;
  }
  public double get_quant(){
    return this.quant;
  }
  public String toString(){
      return "{"+this.nome_produto+", R$ "+this.preco+"}";
  }
}