import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

class Pedido extends ListaProdutos{
  private String codigo;
  private String data;
  private String horario;
  private Usuario usuario;
  public Pedido(Carrinho c){
    super();
    Date dataAtual = new Date();
    DateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
    this.codigo = dateFormat.format(dataAtual);
    dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    this.data = dateFormat.format(dataAtual);
    dateFormat = new SimpleDateFormat("HH:mm:ss");
    this.horario = dateFormat.format(dataAtual);
    this.produtos = (ArrayList) c.getProdutos().clone();
  }
  public String getCodigo(){
    return this.codigo;
  }

  public Usuario getUsuario(){
      return this.usuario;
  }

  public void setUsuario(Usuario u){
      this.usuario = u;
  }
    
  public String toString(){
     String res = ("-----------------------------------\n");
            res += ("PEDIDO: "+codigo+"\n");
            res += ("DATA: "+data+"\n");
            res += ("HORÁRIO: "+horario+"\n");
            res += ("----------------------------------\n");
     int pos = 1;
     double soma = 0;
     for(Produto p : this.produtos){
            res += (pos+"."+p.get_nome_produto()+
                " | R$ "+p.get_preco()+" x "+p.get_quant()+" = "+p.get_preco()*p.get_quant()+"\n");
            soma += p.get_preco()*p.get_quant();
            pos++;
          }
    res += ("-----------------------------------\n");
    res += ("TOTAL: R$ "+soma+"\n");
    res += ("-----------------------------------");
    return res;
 }
}