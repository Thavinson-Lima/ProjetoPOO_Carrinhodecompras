import java.util.*;

class Utilitario{
  private ArrayList<Produto> produtos;
  private ArrayList<Usuario> usuarios;
  private ArrayList<Pedido> pedidos;
    
  public Utilitario(){
    produtos = new ArrayList<Produto>();
    usuarios = new ArrayList<Usuario>();
    pedidos = new ArrayList<Pedido>();
    this.inserirProdutos();
  }

  public void inserirProdutos(){
    //Os produtos são inseridos dentro da lista de produtos, na classe "Produto".
    //NOME MAIÚSCULO
    produtos.add(new Produto("NESCAU","Achocolatado em pó - 200g",6.50));
    produtos.add(new Produto("DELINE","Margarina - 500g",5.00));
    produtos.add(new Produto("LEITE BETANIA"," - Caixa de leite 1L",4.50));
    produtos.add(new Produto("ROSQUINHAS MABEL","Rosquinhas amanteigadas - 500g",7.50));
    produtos.add(new Produto("ARROZ SÃO JOAQUIM","Arroz Branco - 1Kg",4.20));
    produtos.add(new Produto("FEIJÃO BIJU","Feijão Preto - 1Kg",6.00));
  }

  public void inserirUsuario(Usuario usuario){
    usuarios.add(usuario);
  }

  public void cadastrarPedido(Pedido p){
      pedidos.add(p);
  }
  
  public ArrayList<Produto> getProdutos(){
    return this.produtos;
  }

  public ArrayList<Usuario> getUsuarios(){
    return this.usuarios;
  }

  public ArrayList<Pedido> getPedidos(){
    return this.pedidos;
  }
    
}