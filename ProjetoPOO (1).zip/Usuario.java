public class Usuario{
  private String nome;
  private String email;
  private String senha;

  public Usuario(String nome, String email, String senha){
    //O "this" referencia, e indica que o atributo é igual ao parâmetro.
    this.nome = nome;
    this.email = email;
    this.senha = senha;
  }
    //método get que mostra o nome do usuário.
  public String get_nome(){
    return this.nome;
  }
}