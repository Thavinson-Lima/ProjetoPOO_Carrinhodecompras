import java.util.*;

class ListaProdutos{
  protected ArrayList<Produto> produtos;
  public ListaProdutos(){
    produtos = new ArrayList<Produto>();
  }

  public ArrayList<Produto> getProdutos(){
    return this.produtos;
  }

  public void adicionar_produto(Produto produto, double quant){
    boolean produto_repetido = false;
    for(int i = 0; i < produtos.size();i++){
        if(produto.get_nome_produto().equals(produtos.get(i).get_nome_produto())){
            // System.out.println("QA: "+produto.get_quant());
            // System.out.println("NQ: "+quant);
            produto.setQuant(produto.get_quant()+quant);
            produto_repetido = true;
            break;
        }
    }
    if(!produto_repetido){
        produto.setQuant(quant);
        produtos.add(produto);    
    }
  }

  public void setProdutos(ArrayList<Produto> p){
    this.produtos = p;
  }
}