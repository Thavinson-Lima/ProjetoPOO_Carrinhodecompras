import java.util.*;
class Carrinho extends ListaProdutos{
  public Carrinho(){
    super();
  }
  public void exibe_produtos(){
      System.out.println("-----------------------------------");
      System.out.println("--------PRODUTOS DO CARRINHO-------");
      System.out.println("-----------------------------------");
      if(this.getProdutos().size()>0){
          int pos = 1;
          double soma = 0;
          for(Produto p : this.getProdutos()){
            System.out.println(pos+"."+p.get_nome_produto()+
                " | R$ "+p.get_preco()+" x "+p.get_quant()+" = "+p.get_preco()*p.get_quant());
            soma += p.get_preco()*p.get_quant();
            pos++;
          }
          System.out.println("-----------------------------------");
          System.out.println("TOTAL: R$ "+soma);
          System.out.println("-----------------------------------");
      }else{
          System.out.println("-----------CARRINHO VAZIO----------");
      }
  }

  private void limpar_carrinho(){
      this.produtos.clear();
  }

  public void finalizar_pedido(){
      this.limpar_carrinho();
  }

  public Carrinho copia(){
      Carrinho copia = new Carrinho();
      copia.setProdutos(this.produtos);
      return copia;
  }
}