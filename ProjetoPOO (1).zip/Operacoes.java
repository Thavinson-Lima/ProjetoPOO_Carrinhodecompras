import java.util.Scanner;

class Operacoes {
  private Utilitario utilitario = new Utilitario();
  private Carrinho carrinho = new Carrinho();
  private Scanner sc = new Scanner(System.in);
  private Usuario usuarioLogado = null;

  public Utilitario getUtilitario(){
    return this.utilitario;
  }

  public void cadastrarUsuario(){
    System.out.println("DIGITE O NOME DO USUÁRIO: ");
    String nome = sc.nextLine();
    System.out.println("DIGITE O EMAIL DO USUÁRIO: ");
    String email = sc.nextLine();
    System.out.println("DIGITE A SENHA DO USUÁRIO: ");
    String senha = sc.nextLine();
    System.out.println("REPITA A SENHA DO USUÁRIO: ");
    String csenha = sc.nextLine();

    if(!senha.equals(csenha)){
        System.out.println("As senhas não conferem!");
    }else if(senha.length() < 6){
        System.out.println("A senha é muito curta, crie uma mais longa!");
    }else{
        System.out.println("Usuário cadastrado");
        usuarioLogado = new Usuario(nome,email,senha);
        utilitario.inserirUsuario(this.usuarioLogado);
    }
  }

  public void concluir_pedido(){
      System.out.println("DESEJA CONCLUIR O PEDIDO?\nDIGITE S PARA CONCLUIR, Z PARA LIMPAR O CARRINHO, OUTRA TECLA PARA VOLTAR AO MENU: ");
      String resposta = sc.nextLine();
      if(resposta.toUpperCase().equals("S")){
          Pedido p = new Pedido(carrinho.copia());
          p.setUsuario(usuarioLogado); //ATENÇÃO
          carrinho.finalizar_pedido();
          utilitario.cadastrarPedido(p);
          System.out.println("=> PEDIDO CONCLUÍDO");
      }else if(resposta.toUpperCase().equals("Z")){
         carrinho.finalizar_pedido();  
         System.out.println("=> O CARRINHO FOI ESVAZIADO");
      }
  }
  public void gerenciar_carrinho(){
      int escolha_produto = 0;
      do{
          this.carrinho.exibe_produtos();
          System.out.println("-----------------------------------");
          System.out.println("---------LISTA DE PRODUTOS---------");
          System.out.println("-----------------------------------");
          int pos = 1;
          for(Produto p : this.utilitario.getProdutos()){
            System.out.println(pos+"."+p.get_nome_produto()+
                " => R$ "+p.get_preco());
            pos++;
          }
          System.out.println("DIGITE O NÚMERO DO PRODUTO DESEJADO, OU 0(ZERO) PARA VOLTAR AO MENU PRINCIPAL: ");
          escolha_produto = Integer.parseInt(sc.nextLine());
          if(escolha_produto > 0 
          && escolha_produto <= this.utilitario.getProdutos().size()){
            Produto desejado = this.utilitario.getProdutos().get(escolha_produto-1);
            System.out.println("PRODUTO ESCOLHIDO: "+desejado.get_nome_produto());
            System.out.print("DIGITE A QUANTIDADE DO PRODUTO DESEJADO: ");
            double quant = Integer.parseInt(sc.nextLine());
            this.carrinho.adicionar_produto(desejado,quant);
            System.out.println(quant+" UNIDADE(S) DE "+desejado.get_nome_produto()+" FOI(FORAM) ADICIONADO(S)");
          }
          
      }while(escolha_produto != 0);
  }

  public void exibe_catalogo_produtos(){
      System.out.println("-----------------------------------");
      System.out.println("---------LISTA DE PRODUTOS---------");
      System.out.println("-----------------------------------");
      int pos = 1;
      for(Produto p : this.utilitario.getProdutos()){
        System.out.println(pos+"."+p.get_nome_produto()+
            " => R$ "+p.get_preco());
        pos++;
      }
  }

  public void listar_meus_pedidos(){
      System.out.println("-----------------------------------");
      System.out.println("---------LISTA DE PEDIDOS----------");
      System.out.println("-----------------------------------");
      int id = 1;
      for(Pedido p : utilitario.getPedidos()){
         System.out.println((id++)+"º PEDIDO"); 
         System.out.println(p); 
      }
  }
    
  public void exibe_opcoes(){
    
    int resposta = 1;
      do{
      System.out.println("-----------------------------------");
      System.out.println("---------!!!!BEM VINDO!!!!---------");
      System.out.println("-----------------------------------");
      System.out.println("AS OPÇÕES ESTÃO LISTADAS A SEGUIR, DIGITE O CÓDIGO DA OPÇÃO DESEJADA OU PRESSIONE QUALQUER OUTRA OPÇÃO PARA SAIR:");
      System.out.println("1. CADASTRAR USUÁRIO");
      System.out.println("2. CATÁLOGO DE PRODUTOS");
      System.out.println("3. GERENCIAR CARRINHO DE COMPRAS");
      System.out.println("4. CONCLUIR PEDIDO");
      System.out.println("5. LISTAR MEUS PEDIDOS");

      if(usuarioLogado != null){
          System.out.println("Você está logado como ("+usuarioLogado.get_nome()+")");
      }
      System.out.print("DIGITE SUA OPÇÃO: ");
      resposta = Integer.parseInt(sc.nextLine());
  
      switch(resposta){
        case 1:
          this.cadastrarUsuario();
          break;
        case 2:
          this.exibe_catalogo_produtos();
          break;
        case 3:
          this.gerenciar_carrinho();
          break;
        case 4:
          this.concluir_pedido();
        case 5:
          this.listar_meus_pedidos();
        default:
          break;
      }
    }while(resposta <= 4 && resposta > 0);
  }
}