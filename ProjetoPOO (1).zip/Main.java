import java.util.Scanner;

class Main {
  
  public static void main(String[] args) {
    Operacoes op = new Operacoes();
    op.exibe_opcoes();
  }
}